#ifndef defines_h
#define defines_h

#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>



// fix
#define paketSize 64	//HID Paketgröße immer 64 byte


#define SYNCBYTE1		0x53	//Syncbytes OptiSense 'S' (Buffer[0])
#define SYNCBYTE2		0x54    //Syncbytes OptiSense 'T' (Buffer[1])
#define COMPONENTID     0x00    //command                 (Buffer[2])

#endif







