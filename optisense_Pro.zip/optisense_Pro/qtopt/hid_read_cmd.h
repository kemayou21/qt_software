#ifndef HID_READ_CMD_H
#define HID_READ_CMD_H

#include <stdio.h>
#include <stdlib.h>
#include <QMainWindow>
#include "define.h"

bool VendorProduct_ID(int ve_id, int pr_id);


unsigned char cmdID_01(int index, unsigned char buf_5,unsigned char buf_6);
unsigned char cmdID_02(int index, unsigned char buf_5,unsigned char buf_6);
unsigned char cmdID_03(int index, unsigned char buf_5,unsigned char buf_6,unsigned char buf_7,unsigned char buf_8);
unsigned char cmdID_04(int index, unsigned char buf_5,unsigned char buf_6,unsigned char buf_7,unsigned char buf_8);
void ReceivedBuffer(unsigned char *batchnumb);
float ReadOffloadData(int index);
uint32_t ReadNumberOfSpamleInBatch(unsigned char *batchnumb);
void interpretCmd(unsigned char *buf_send,unsigned char *buf_receive);
bool checkCRC(unsigned char *buf_r,unsigned char payload, uint32_t buf_len);
bool checkSync(unsigned char *buffer);	//checkt ob sync-unsigned chars richtig sind




#endif // HID_READ_CMD_H
