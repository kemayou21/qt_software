#ifndef QT_CMD_H
#define QT_CMD_H


#define v 2 // vendor ID
#define p 2 // product ID

int vpid[v][p]={{5824,1158},
                {6988,65280},};

int V_P_ID(int v_id, int p_id);



#endif // QT_CMD_H
