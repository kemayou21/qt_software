#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "define.h"
#include "hid_read_cmd.h"


MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);



    MainwindowResize();
    start_seite();
    set_Button();
    init_tableWidget_read();
    Curve_init();	//Main***

    PaintChecker_select();
    init_device();
    m_counter=1000;
    m_timer1= new QTimer(this);
 QObject::connect(m_timer1,SIGNAL(timeout()), this, SLOT(Heart_Beat()));
 m_timer1->start(m_counter);
 QObject::connect(group,SIGNAL(buttonClicked(QAbstractButton*)),this,SLOT(Batch_ID_Lesen(QAbstractButton*)));


}

MainWindow::~MainWindow()
{
    delete curve1;
    delete plotLayout;	//delete***
    delete curve2;
    delete plotLayout2; //delete***
    delete ui;
 }
//**********************************************
//MainWindow Resize
//**********************************************
void MainWindow::MainwindowResize()
{
    QSize deskSize= qApp->desktop()->availableGeometry().size();
    int width= deskSize.width();
    int height= deskSize.height();
    //qDebug()<<"PC Size:"<< width << "x" <<height;
    height *=  0.97;// höhe auf 97% reduzieren
    //width *=  0.98;
    QSize newSize(width,height);
    MainWindow::setGeometry(QStyle::alignedRect(Qt::LeftToRight,Qt::AlignBottom,newSize,qApp->desktop()->availableGeometry()));
    MainWindow::setWindowIcon(QIcon(":/files/window_icon/OS_Quadrate.bmp"));
    MainWindow::setWindowTitle("PaintChecker");

}


// CloseEvent MessageBox
void MainWindow::closeEvent(QCloseEvent *event)
{
    event->ignore();
    QMessageBox msgbox(QMessageBox::Question,tr("Beenden"),
                       tr("Wollen Sie Wirklich Das Programm beenden"),
                       QMessageBox::Yes|QMessageBox::No,this);
    msgbox.setButtonText(QMessageBox::Yes,tr("Ja"));
    msgbox.setButtonText(QMessageBox::No,tr("Nein"));
    if(msgbox.exec()==QMessageBox::Yes){

       event->accept();

    }

}

//TabsMenu Set
void MainWindow::start_seite()
{
    ui->gridLayout->setContentsMargins(0,0,0,0); //Window ohne Rand
    ui->gridLayout_4->setContentsMargins(0,0,0,0);
    ui->gridLayout_5->setContentsMargins(0,0,0,0);
    ui->frame->setContentsMargins(0,0,0,0);
    //ui->gridLayout_4->setContentsMargins(0,0,0,0);
    ui->frame_2->setContentsMargins(0,0,0,0);
    ui->frame_3->setContentsMargins(0,0,0,0);
    ui->frame_2->setStyleSheet("background-color:none");
    ui->frame_3->setStyleSheet("background-color:none");
    ui->frame->setStyleSheet("background-color:rgb(157,0,45)");
    ui->tabWidget->setContentsMargins(0,0,0,0);



    QPixmap pix_label(":/files/window_icon/OptiSense_2.png");
    ui->label->setPixmap(pix_label.scaled(256,66,Qt::KeepAspectRatio));
    ui->tabWidget->removeTab(5);
    ui->tabWidget->removeTab(4);
    ui->tabWidget->removeTab(3);
    ui->tabWidget->removeTab(2);
    ui->tabWidget->removeTab(1);


}

//**********************************************
//Widgets designen
//Buttons, Combobox, ...
//**********************************************
void MainWindow::set_Button()
{
    QPixmap pix_lamp_rot,  pix_info, pix_hilfe, pix_neu, pix_loeschen, pix_speichern, pix_trigger, pix_tools;
    QColor transparent(0,0,0,0);
    pix_herz.load(":/files/button_icon/herz_rot.png");


    QPalette tr_h_palette(ui->pushButton_herz->palette());
    tr_h_palette.setColor(QPalette::Button,transparent);
    ui->pushButton_herz->setPalette(tr_h_palette);
    ui->pushButton_herz->setIcon(pix_herz);
    ui->pushButton_herz->setContentsMargins(0,0,0,0);
    ui->pushButton_herz->setStyleSheet("border:none");


    pix_lamp_rot.load(":/files/button_icon/lampe_rot.png");
    QPalette tr_l_palette(ui->pushButton_lamp->palette());
    tr_l_palette.setColor(QPalette::Button,transparent);
    ui->pushButton_lamp->setPalette(tr_l_palette);
    ui->pushButton_lamp->setIcon(pix_lamp_rot);
    ui->pushButton_lamp->setStyleSheet("border:none");

    pix_info.load(":/files/button_icon/info.png");
    QPalette tr_i_palette(ui->pushButton_info->palette());
    tr_i_palette.setColor(QPalette::Button,transparent);
    ui->pushButton_info->setPalette(tr_i_palette);
    ui->pushButton_info->setIcon(pix_info);
    ui->pushButton_info->setStyleSheet("border:none");

/*Sprache icons setzen*/
    QIcon ico_de(":/files/button_icon/Germany-Flag.ico");
    QIcon ico_en(":/files/button_icon/England-Flag.ico");
    QIcon ico_fr(":/files/button_icon/France-Flag.ico");
    QIcon ico_chn(":/files/button_icon/China-Flag.ico");
    ui->comboBox->addItem("DE");
    ui->comboBox->addItem("EN");
    ui->comboBox->addItem("FR");
    ui->comboBox->addItem("CHN");
    ui->comboBox->setItemIcon(0,ico_de);
    ui->comboBox->setItemIcon(1,ico_en);
    ui->comboBox->setItemIcon(2,ico_fr);
    ui->comboBox->setItemIcon(3,ico_chn);
//    ui->comboBox->setStyleSheet("QComboBox{"
//                                "border-radius: 3px;"
//                                "background-color: none;"
//                                "padding: 1px 18px 1px 3px;""}"
//                                "QComboBox QAbstractItemView{background:none};"
//                                );
// Pushbutton hilfe
    pix_hilfe.load(":/files/button_icon/help-browser.png");
    QPalette hilfe(ui->pushButton_hilfe->palette());
    hilfe.setColor(QPalette::Button,transparent);
    ui->pushButton_hilfe->setPalette(hilfe);
    ui->pushButton_hilfe->setIcon(pix_hilfe);
// Pushbutton neu
    pix_neu.load(":/files/button_icon/document-new.png");
    QPalette neu(ui->pushButton_neu->palette());
    neu.setColor(QPalette::Button,transparent);
    ui->pushButton_neu->setPalette(neu);
    ui->pushButton_neu->setIcon(pix_neu);
// Pushbutton loeschen
    pix_loeschen.load(":/files/button_icon/loeschen.png");
    QPalette loeschen(ui->pushButton_loeschen->palette());
    loeschen.setColor(QPalette::Button,transparent);
    ui->pushButton_loeschen->setPalette(loeschen);
    ui->pushButton_loeschen->setIcon(pix_loeschen);
// Pushbutton pix_speichern
    pix_speichern.load(":/files/button_icon/document-save.png");
    QPalette speichern(ui->pushButton_speichern->palette());
    speichern.setColor(QPalette::Button,transparent);
    ui->pushButton_speichern->setPalette(speichern);
    ui->pushButton_speichern->setIcon(pix_speichern);
// Pushbutton pix_trigger
    pix_trigger.load(":/files/button_icon/trigger.png");
    QPalette trigger(ui->pushButton_trigger->palette());
    trigger.setColor(QPalette::Button,transparent);
    ui->pushButton_trigger->setPalette(trigger);
    ui->pushButton_trigger->setIcon(pix_trigger);
// Pushbutton pix_tools
    pix_tools.load(":/files/button_icon/tools.png");
    QPalette tools(ui->toolButton_setting->palette());
    tools.setColor(QPalette::Button,transparent);
    ui->toolButton_setting->setPalette(tools);
    ui->toolButton_setting->setIcon(pix_tools);
}

void MainWindow::PaintChecker_select()
{
//    ui->comboBox_2->addItem("");
//    ui->comboBox_2->addItem("Automation");
//    ui->comboBox_2->addItem("Mobile");
   // ui->comboBox_2->addItems("Industrie");
}

//**********************************************
//Tabs Je nach Gerät auswählen
//**********************************************
void MainWindow::on_comboBox_2_activated(const QString)
{
    QString selected= ui->comboBox_2->currentText();
    if(selected=="..."){
      QMessageBox::information(this,tr("info"), tr("kein Geräte wurde ausgewählt!"));
    }

    if(selected=="TQC GLOSSMETER"){

       handle = hid_open(v_ID, p_ID, NULL);

      //ui->tabWidget->removeTab(5);
      ui->tabWidget->removeTab(4);
      //ui->tabWidget->removeTab(3);
      //ui->tabWidget->removeTab(2);
      ui->tabWidget->removeTab(1);
      ui->tabWidget->removeTab(0);
      ui->tabWidget->addTab(ui->tab_3, tr("Daten Lesen"));
      ui->tabWidget->addTab(ui->tab_4,tr("Kalibrierung"));
    }

    else if(selected=="Automation")
        {
        //ui->tabWidget->removeTab(5);
        //ui->tabWidget->removeTab(4);
        ui->tabWidget->removeTab(3);
        ui->tabWidget->removeTab(2);
        //ui->tabWidget->removeTab(1);
        ui->tabWidget->removeTab(0);
        ui->tabWidget->addTab(ui->tab_2, tr("Messung"));
        ui->tabWidget->addTab(ui->tab_4,tr("Kalibrierung"));
        }
    else if(selected=="MOBILE")
    {
        //ui->tabWidget->removeTab(5);
        ui->tabWidget->removeTab(4);
        ui->tabWidget->removeTab(3);
        ui->tabWidget->removeTab(2);
        ui->tabWidget->removeTab(1);
        ui->tabWidget->removeTab(0);
        ui->tabWidget->addTab(ui->tab,"Main Tab");
    }


}

//**********************************************
//Curve 1 der Seite Live Messung initialisieren
//**********************************************
void MainWindow::Curve_init()
{
    /*Curve1 initialisieren*/
    plotLayout= new QGridLayout;
    plotcurve1=new QwtPlot;
    plotLayout->addWidget(plotcurve1,0,0);
    plotLayout->setContentsMargins(0,0,0,0);
    ui->frame_4->setLayout(plotLayout);
    plotcurve1->setContentsMargins(5,5,5,5);

    QwtText xtitle1(tr("Messung/#"));
    xtitle1.setFont(QFont("Times New Roman",14));
    plotcurve1->setAxisTitle(QwtPlot::xBottom, xtitle1);
    plotcurve1->setAxisScale(QwtPlot::xBottom,0,1);

    QwtText ytitle1(tr("Schichtdicke/µm"));
    ytitle1.setFont(QFont("Times New Roman",14));
    plotcurve1->setAxisTitle(QwtPlot::yLeft, ytitle1);
    plotcurve1->setAxisScale(QwtPlot::yLeft,0,1);

    curve1= new QwtPlotCurve("Kennlinie");
    curve1->setPen(Qt::red,2);
    curve1->setRenderHint(QwtPlotItem::RenderAntialiased, true);
    plotcurve1->setFrameStyle(QFrame::Plain);
//    grid1= new QwtPlotGrid;
//    grid1->setMajorPen(Qt::gray, 1);
//    grid1->attach(plotcurve1);
/*Curve2 initialisieren*/
    plotLayout2= new QGridLayout;
    plotcurve2=new QwtPlot;
    plotLayout2->addWidget(plotcurve2,0,0);
    plotLayout2->setContentsMargins(0,0,0,0);
    ui->frame_7->setLayout(plotLayout2);
    plotcurve2->setContentsMargins(5,5,5,5);

    QwtText xtitle2(tr("Messung/#"));
    xtitle2.setFont(QFont("Times New Roman",14));
    plotcurve2->setAxisTitle(QwtPlot::xBottom, xtitle2);
    plotcurve2->setAxisScale(QwtPlot::xBottom,0,1,1); // Schritte Anzahl

    QwtText ytitle2(tr("Schichtdicke/µm"));
    ytitle2.setFont(QFont("Times New Roman",14));
    plotcurve2->setAxisTitle(QwtPlot::yLeft, ytitle2);
    plotcurve2->setAxisScale(QwtPlot::yLeft,0,1,1);


    curve2= new QwtPlotCurve("Kennlinie");
    curve2->setPen(Qt::red,2);
    curve2->setRenderHint(QwtPlotItem::RenderAntialiased, true);
    plotcurve2->setFrameStyle(QFrame::Plain);
    grid2= new QwtPlotGrid;
    grid2->setMajorPen(Qt::black,0,Qt::DotLine);
    grid2->setMinorPen(QPen(Qt::gray,0,Qt::DotLine));
    grid2->attach(plotcurve2);

    QwtSymbol *symbol = new QwtSymbol (QwtSymbol:: Ellipse,
            QBrush (Qt:: yellow), QPen (Qt:: red, 2), QSize (8, 8));
        curve2->setSymbol (symbol);
}

//**********************************************
//Curve 2 Seite Read Data initialisieren
//**********************************************
void MainWindow::Curve2_plotten()
{
   int b_ID= selected_Batch-1, j=0;
   int row= tabelle[b_ID].virt_table->rowCount();
   qDebug()<<"Batch ID"<<b_ID<<"Tabelle Anzahl Zeile:"<<row;
   for(int i=0;i<m_batchAnzahl;i++){
       m_x[i]=i+1;

   }
   while(j<m_batchAnzahl){
       m_points<<QPointF(m_x[j],m_y[j]);
       qDebug()<<"********************************Plot MessWert"<<m_y[j];
       j++;
   }
    plotcurve2->setAxisScale(QwtPlot::xBottom,0,m_x[j-1],1); // X-Axe Skalierung
//   plotcurve2->setAxisScaleDiv(QwtPlot::xBottom, 1);
   plotcurve2->setAxisAutoScale(QwtPlot::yLeft,true);
   curve2->setSamples(m_points);
   //curve1->setRawSamples(m_x, m_y, rw); // m_x und m_y müssen in Private in der Parent klasse deklariert damit die curve angezeigt wird
   curve2->attach(plotcurve2);
   plotcurve2->replot();
   plotcurve2->show();
}


//**********************************************
//Check TableWidgetItem  keine Wirkungen
//**********************************************
void MainWindow::tableWidget_checked(int row, int column)
{
    if(column==0){
       if(ui->tableWidget_2->item(row,0)->checkState()==Qt::Checked){
          qDebug()<<"checked";}
       else{
          ui->tableWidget_2->item(row,0)->setCheckState(Qt::Unchecked);}
    }
    else
    {
        qDebug()<<"wrong cell!";
    }
}

//**********************************************
//Timer setzen
//**********************************************
void MainWindow::Heart_Beat()
{
    //cmdID_01();
    //data_send();
    //data_receive;
    if (m_counter%2)
        {
            pix_herz.load(":/files/button_icon/herz_rot.png");
            ui->pushButton_herz->setIcon(pix_herz);
            m_counter++;
        }
        else{
             pix_herz.load(":/files/button_icon/herz_gruen.png");
             ui->pushButton_herz->setIcon(pix_herz);
             m_counter--;
        }
}

//Update Devices
void MainWindow::on_pushButton_Update_Device_clicked()
{
  init_device();
}

//**********************************************
//Geräte Info MessageBox
//**********************************************
void MainWindow::on_pushButton_info_clicked()
{
     QString selected= ui->comboBox_2->currentText();
     if(selected=="..."){
     QMessageBox::information(this,tr("info"), tr("kein Geräte wurde ausgewählt!"));
  }
  else{
    for(int c=0; c<5;c++){
        if(selected==product_String[c]){
             //QString status= QString(tr("Aktuelle Geräte:\nManufacturer: %1\nProdukt:     %2")).arg(manufact_Name).arg(product_String);
             QMessageBox::information(this,tr("info"), m_deviceinfo[c]);
        }
    }
  }
}

//**********************************************
//Daten Exportieren
//**********************************************
void MainWindow::on_pushButton_export_clicked()
{
   int row= ui->tableWidget->rowCount();
   int col= ui->tableWidget->columnCount();
   QString format= "csv";
   QString werte="";
/*Path */
   QString path= QStandardPaths::writableLocation(QStandardPaths::DesktopLocation);
        path +=tr("/untited.")+format;
   QString fileName=QFileDialog::getSaveFileName(this, tr("Save As"),
                 path,tr("%1 Files (*.%2);;All Files (*)")
                 .arg(format.toUpper()).arg(format));
   if(fileName!=""){
     QFile file(fileName);
     if(!file.open(QIODevice::WriteOnly)){
      QMessageBox::information(this,tr("information"),tr("unmöglich zu Öffnen"));
     }
     else{

      QTextStream stream(&file);
      int i=0;
      int j=0;
      while(i<row){
       while(j<col){
        werte+= ui->tableWidget->model()->index(i,j).data().toString();
        werte+= ";";
        j++;
        }
       j=0;
       werte+= "\n";
       i++;
     }
     stream<<werte;
     file.close();
        }}

}

//**********************************************
//Tabelle der Seite read Data setzen
//**********************************************
void MainWindow::init_tableWidget_read()
{
    int row= ui->tableWidget_2->rowCount();
    ui->tableWidget_2->setRowCount(row);
    item_tableWidget_2=new QTableWidgetItem(tr("Messreihe"));

    ui->tableWidget_2->setHorizontalHeaderItem(0,item_tableWidget_2);
    group= new QButtonGroup(ui->tableWidget_2);     // Damit nur der Selectierte makiert wird

    for(int i=0; i<row; i++){
     button= new QPushButton(QString(tr("Batch#%1")).arg(i+1));

     button->setCheckable(true);
     ui->tableWidget_2->setCellWidget(i,0,button); // Damit wird ein ein Button in der Zelle eingebracht

     group->addButton(button);
     button->setDisabled(true);
     }
    group->setExclusive(true); // Damit nur ein Button aus der Gruppe als selektiert angezeigt wird
}

//**********************************************
//READ DATA from Device
//**********************************************
void MainWindow::on_pushButton_ReadData_clicked()
{

   c_tab= 0;
   int k=3, m=0;                                               //Zähler für die Batch ID Value
   int row=ui->tableWidget_2->rowCount();                      //Tabelle Zähler initialisieren

   for(int i=0; i<row; i++){
       ui->tableWidget_2->cellWidget(i,0)->setEnabled(false);
   }
   for(int i=0; i<10;i++){                                      // commande Befehl ab stelle 4
        buf_s[i]= cmdID_03(i,0x00,0x00,0x00,0x00);                     // Protoype cmd in define.cpp
   }
   data_send();
   qDebug()<<"LogggedBatchIDs Angefragt....";
   data_receive();

   int batch_id_anzahl;
   BatchID_Anzahl= buf_r[5];
   batch_id_anzahl=BatchID_Anzahl;
   qDebug()<<"NumberOfBatches ID:"<<batch_id_anzahl;


   //Show and Enable Buttons
   k=3;                         //Button Zähler setzen
   /* Button ID Idenfizierung
    * Zuweisung an Batch Button startwer= -2
   */
   for(int i=0; i<batch_id_anzahl; i++){
       c_tab=buf_r[k*2];
       m= (-1)*(c_tab+1);       // Zuweisung an Batch, Button startwert allg= -2;

       group->QButtonGroup::button(m)->setText(QString("Batch#%1").arg(c_tab));

    if(c_tab<=9){                                                //c_tab ist zelle zähler vergeleich mit default Anzal von zeile

        ui->tableWidget_2->cellWidget(c_tab-1,0)->setEnabled(true);  //Zelle Enabled c_tab-1 Tabelle beginnt mit 0
        c_tab++;
        k=k+1;
    }

     else if(c_tab>9 && c_tab<50){                              // 50 weil die Tabellen Anzahl auf 50 begrentz ist

        row=c_tab+1;
        ui->tableWidget_2->setRowCount(row);
        button= new QPushButton(QString(tr("Batch#%1")).arg(c_tab));
        button->setCheckable(true);
        group->addButton(button);
        ui->tableWidget_2->setCellWidget(c_tab-1,0,button); // Damit wird ein ein Button in der Zelle eingebracht
        group->setExclusive(true);
        c_tab++;
        k=k+1;
     //Messreihe hinzufügen
    }
    else {
    QMessageBox::information(this,tr("info"), tr("Die Tabelle ist voll bitte zurücksetzen!"));
    }

   }

}


//**********************************************
//BATCH ID : Batch ID number lesen
//**********************************************
int MainWindow::Batch_ID_Lesen(QAbstractButton* messnr)
{
   int messnummer;
   qDebug()<< abs(group->QButtonGroup::id(messnr));
   messnummer= abs(group->QButtonGroup::id(messnr));
   selected_Batch= messnummer;
   messnummer=messnummer-1;
//   if(messnummer==2){
//       buf_s[0]=0;
//       buf_s[1]=SYNCBYTE1;
//       buf_s[2]=SYNCBYTE2;
//       buf_s[3]=COMPONENTID;
//       data_send();
//       data_receive();
//   }
   Batch_Value(messnummer);
   Curve2_plotten();
   return messnummer;

}

//**********************************************
//BATCH  : Read Batch value
//Messwerte entnehmen
//**********************************************
void MainWindow::Batch_Value(int val)
{
    float r_0,r_3,r_4,r_5,r_6;
    int r=0;                                                  //Zeile und Spalte zähler
    tabelle[val].virt_table= new QTableWidget;
    tabelle[val].virt_table->setRowCount(r+1);
    for(int i=0; i<10;i++){                                        // Command NUMBER OF SAMPLES Array= 7
         buf_s[i]= cmdID_03(i,0x03,0x00,val,0x00);                 // Protoype cmd in define.cpp
    }

    data_send();
    qDebug()<<"Batch ID # Number of Sample Angefragt....";
    data_receive();
    uint32_t batch_number= ReadNumberOfSpamleInBatch(buf_r);       // Messwerte Anzahl
    m_batchAnzahl=batch_number;
    qDebug()<<"BatchID"<<val<<" Sample Number:"<< batch_number;
    for (uint32_t i=0; i<=batch_number; i++){
        for(int j=0; j<10;j++){                                    // Command OFFLOAD DATA Array= 5
             buf_s[j]= cmdID_04(j,val,0x00,i,0x00);                // Protoype cmd in define.cpp
        }

        data_send();
         qDebug()<<i<<"Anfrage Batch value send";
        data_receive();
        ReceivedBuffer(buf_r);                                     // Buffer lesen
        if(i!=0){                                                  /*!=0:Sequenz 0 für Spezial reserviert*/

           r_0= ReadOffloadData(0);                                //Zeit
           r_3= ReadOffloadData(3);                                //Korr. Wert
           m_y[r]=r_3;
           r_4= ReadOffloadData(4);                                //Raw Wert
           r_5= ReadOffloadData(5);                                //Phase 1
           r_6= ReadOffloadData(6);                                //Phase 2

           Batch_Tabelle(val, r, r_0, r_3, r_4, r_5, r_6);
           r++;

        }
    }
}

//*****************************************************
//verbindung zwischen tabelle und Messreihe
//Intitialisierung der Virtuelle Tabelle
//Speicherung von jede Messpunkte in der Virt. Tabelle
//*****************************************************
void MainWindow::Batch_Tabelle(int batch_id, int counter, float zeit, float korr_wert, float raw_wert, float phase_1, float phase_2)
{
    int r;
    r=counter;
    item_zeit= new QTableWidgetItem;
    item_zeit->setData(Qt::EditRole,zeit);
    item_kor= new QTableWidgetItem;
    item_kor->setData(Qt::EditRole,korr_wert);
    item_raw= new QTableWidgetItem;
    item_raw->setData(Qt::EditRole,raw_wert);
    item_ph1= new QTableWidgetItem;
    item_ph1->setData(Qt::EditRole,phase_1);
    item_ph2= new QTableWidgetItem;
    item_ph2->setData(Qt::EditRole,phase_2);
    tabelle[batch_id].virt_table->setItem(r,r,item_zeit);
    tabelle[batch_id].virt_table->setItem(r,r+1,item_kor);
    tabelle[batch_id].virt_table->setItem(r,r+2,item_raw);
    tabelle[batch_id].virt_table->setItem(r,r+3,item_ph1);
    tabelle[batch_id].virt_table->setItem(r,r+4,item_ph2);


}

//**********************************************
//Devices Initialisierung
//VID, PID, ManufacturerName, Produkt Name
//**********************************************
void MainWindow::init_device()
{
    //m_deviceinfo[5]={""};
   // product_String[5]={""};
    int vid, pid, s=0; // s manufact_Name index, t Produkt name
    ui->comboBox_2->clear();
    ui->comboBox_2->addItem("...");
    devs = hid_enumerate(0x0, 0x0);// VID=0 PID=0; Alle HID werden gelistet
    cur_dev = devs;
    dev_event= devs;

    while (cur_dev) {
    vid=cur_dev->vendor_id;
    pid=cur_dev->product_id;
// Falls eine unserem Gerät erkannt wurde.
   if(VendorProduct_ID(vid,pid)){
    int int_numb=cur_dev->interface_number;
    if(int_numb<=0){
    v_ID=cur_dev->vendor_id;
    p_ID=cur_dev->product_id;

    m_deviceinfo[s]=QString(tr("%1")).asprintf("Manufacturer: %ls\nProduct          : %ls",cur_dev->manufacturer_string,cur_dev->product_string);
    product_String[s]=QString(" %1").asprintf("%ls",cur_dev->product_string);
    ui->comboBox_2->addItem(product_String[s]);
    s++;
    }
     cur_dev = cur_dev->next;
   }
   else{
     cur_dev = cur_dev->next;
   }
  }
  hid_free_enumeration(devs);
}

//**********************************************
//CHECKSUMME Berechnung:
//Gibt den ein wert zurück
//**********************************************
uint32_t MainWindow::checksumme(unsigned char *msg_crc, uint32_t payloadlen_crc, int id_crc )
{
    uint32_t i,j;
    uint32_t k=0;
    uint32_t crc;
    crc = 0;//0xFFFFFFFF;

    k=payloadlen_crc;
/*sende Key = 123*/
    if(id_crc==123){

        qDebug()<<"payloadlänge buf_s:"<<payloadlen_crc;
        msg_crc=msg_crc+1;
        for (i=1; i<=k; i++)
        {
          //qDebug()<<"mes"<<*msg_crc;
          crc = crc ^ *msg_crc++ ;
          for (j=0; j<8; j++)
          {
            if (crc & 1)
             crc = (crc>>1) ^ 0xEDB88320 ;
            else
             crc = crc >>1 ;

          }
        }

      return crc;
    }
/*receive Key = 321*/
    else if (id_crc==321){
        qDebug()<<"payload buf_r:"<<payloadlen_crc;
        for (i=0; i<k; i++)
        {
           crc = crc ^ *msg_crc++ ;
          for (j=0; j<8; j++)
          {
            if (crc & 1)
             crc = (crc>>1) ^ 0xEDB88320 ;
            else
             crc = crc >>1 ;

          }
        }
        return crc;
    }
    else{
        uint32_t erro;
        return erro= 800;         // Printf error code number
    }

}

//**********************************************
//Send Command
//**********************************************
void MainWindow::data_send()
{
    unsigned char  len_send;         // 5: cmd= 2 + cid= 1 + 00= 1 + payload= 1;
    uint32_t chksumm;
    int id_s=123;                       //Sende ID für Checksumme
    uint32_t k=0, s=0;
   // init_device();

  //  hid_set_nonblocking(handle, 0);                       // der verhinderte der Rx die Leitung blockiert

    len_send= buf_s[5] + 5;
    qDebug()<<"Payload send länge"<<len_send;
    chksumm=checksumme(buf_s,len_send, id_s);
    k= len_send;                  // cheksumme werte in buffer laden buf[k]
    buf_s[k+1] = chksumm & 0xff;
    buf_s[k+2] = ( chksumm >> 8 ) & 0xff;
    buf_s[k+3] = ( chksumm >> 16 ) & 0xff;
    buf_s[k+4] = ( chksumm >> 24 ) & 0xff;
    k= k+5;         // buffer nach der cheksumme auf null setzten

    for (s=k; s<len; s++)
    {
      buf_s[s]=0;
    }
    res=hid_write(handle,buf_s,64); // erste byte als ReportID=0 setzen.=>buf[0]=0
    qDebug()<<"Buffer gesendet:"<<res;
    //data_receive();
//    hid_close(handle);
//    hid_exit();
    Sleep(50);
}

//**********************************************
//Receive Data
//**********************************************
void MainWindow::data_receive()
{
    bool crc=false;
    bool sync=false;
    //unsigned char send_b[2];
    unsigned char payloadlen_r=0;
   // send_b[0]=buf_s[4];                                     //Befehl
   // send_b[1]=buf_s[6];                                     //Befehl
    res = hid_read(handle, buf_r, 64);
    qDebug()<<res;
  //  hid_set_nonblocking(handle, 1);


    if (res < 0){
           ui->textEdit->setText("");
           ui->textEdit->append("Unable to read Date...\n");
           qDebug()<<"Unable to read Date...";
           QMessageBox::information(this,tr("Info"),tr("Data Auslesen unmöglich."));
           //exit(-1);

       }
    else{
          payloadlen_r=buf_r[4]+5;                                //Payloadlänge Ausrechnung

          qDebug()<<"read_info State"<<read_info;
          crc=  checkCRC(buf_r, payloadlen_r, len);               //Checksumme prüfen
          sync= checkSync(buf_r);                                 //Checksynchrone prüfen

         if(crc && sync){
         //interpretCmd(send_b,buf_r);                //Befehl interpretieren
             qDebug()<<"Checksumme und CheckSynchr o.k";
         }
         else{
             qDebug()<<"Checksumme oder Checksynchron falsch!";
             //QMessageBox::warning(this,tr("Info"),tr("Checksumme oder Checksynchron falsch!"));
     }
 }
}

//**********************************************
//Delete Selection
//**********************************************
void MainWindow::on_pushButton_delete_Selection_clicked()
{
    int sel= selected_Batch;
    int messnr=sel-2;                         //group Button ID zähl ab 2;
    qDebug()<<"delete Selection number:"<<messnr;
    if(messnr<0||messnr>51){
       QMessageBox::information(this,tr("Info"),tr("kein Messreihe wurde ausgewählt"));
    }
    else{
        QMessageBox msgbox(QMessageBox::Warning,tr("löschen"),
                           QString(tr("Wollen Sie Wirklich Messreihe#%1 löschen?").arg(messnr+1)),
                           QMessageBox::Yes|QMessageBox::No,this);
        msgbox.setButtonText(QMessageBox::Yes,tr("Ja"));
        msgbox.setButtonText(QMessageBox::No,tr("Nein"));
        if(msgbox.exec()==QMessageBox::Yes){
        ui->tableWidget_2->cellWidget(messnr,0)->setEnabled(false);
      }
    }
}
//**********************************************
//Delete All
//**********************************************
void MainWindow::on_pushButton_delete_All_clicked()
{
    int row= ui->tableWidget_2->rowCount();
    QMessageBox msgbox(QMessageBox::Warning,tr("löschen"),
                       tr("Wollen Sie Alle Messreihen löschen?"),
                       QMessageBox::Yes|QMessageBox::No,this);
    msgbox.setButtonText(QMessageBox::Yes,tr("Ja"));
    msgbox.setButtonText(QMessageBox::No,tr("Nein"));
    if(msgbox.exec()==QMessageBox::Yes){
        for(int i=0; i<row; i++){
           ui->tableWidget_2->cellWidget(i,0)->setEnabled(false);
        }
      ui->tableWidget_2->setRowCount(10);

      c_tab=0;
    }
}
