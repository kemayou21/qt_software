#include "mainwindow.h"
#include <QApplication>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    MainWindow w;
    w.setWindowIcon(QIcon(":/files/window_icon/OS_Quadrate.bmp"));
    w.setWindowTitle("PaintChecker");
    w.show();

    return a.exec();
}
