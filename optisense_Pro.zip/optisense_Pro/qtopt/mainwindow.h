#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QDialog>
#include <QMainWindow>
#include <QDesktopWidget>
#include <QStyle>
#include <QDebug>
#include <QtWidgets>
#include <QMessageBox>
#include <QHeaderView>
#include <qwt_plot_curve.h>
#include <qwt_plot.h>
#include <qwt_plot_grid.h>
#include <qwt_point_data.h>
#include <qwt_legend.h>
#include <qwt_symbol.h>
#include <QTimer>
#include<QTime>
#include <QAbstractButton>
#include "hidapi.h"
#include "hid_read_cmd.h"


#define virtRow     100
#define virtColumn  999


namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();

    void MainwindowResize();
    void closeEvent(QCloseEvent *event);
    void start_seite();
    void set_Button();
    void PaintChecker_select();
    void Curve_init();
    void Curve2_plotten();
    void init_tableWidget_read();
    void tableWidget_checked(int row, int column);
    void init_device();
    int V_P_ID(int v_id, int p_id);
    void Batch_Tabelle(int batch_id, int counter, float zeit, float korr_wert, float raw_wert, float phase_1, float phase_2);
    uint32_t checksumme(unsigned char *msg_crc, uint32_t payloadlen_crc, int id_crc);
    void data_send();
    void data_receive();
    void sendDeviceSerialNo();
    void Batch_Value(int val);
 //   void interpretCmd(unsigned char *buf_send,unsigned char *buf_receive, bool CRC, bool SYNC);


public slots:
    void Heart_Beat();
    int Batch_ID_Lesen(QAbstractButton* messnr);

private slots:



    void on_pushButton_Update_Device_clicked();

    void on_pushButton_info_clicked();

    void on_comboBox_2_activated(const QString);

    void on_pushButton_export_clicked();

    void on_pushButton_ReadData_clicked();



    void on_pushButton_delete_Selection_clicked();

    void on_pushButton_delete_All_clicked();

private:
    Ui::MainWindow *ui;
//*****************PlotCurve*********************//
    QGridLayout *plotLayout, *plotLayout2;
    QwtPlotCurve *curve1, *curve2;
    QwtPlot *plotcurve1, *plotcurve2;
    QwtPlotGrid *grid1, *grid2;
    QPolygonF m_points;
    QTableWidgetItem *item_tableWidget_2;
    QTableWidgetItem *item1;
    QTableWidgetItem *item_zeit;
    QTableWidgetItem *item_kor;
    QTableWidgetItem *item_raw;
    QTableWidgetItem *item_ph1;
    QTableWidgetItem *item_ph2;
    QTableWidget *virtualtableWidget_1;
//*****************Group Button*********************//
    QPushButton *button;
    QButtonGroup *group;
    QComboBox *combo;
//*****************Timer****************************//
    int m_counter;
    QPixmap pix_herz, pix_herz_gruen;
    QTimer *m_timer1;
//*****************Buffer Parameter*****************//
    int v_ID=0, p_ID=0;
    int res, id, selected_Batch=0, BatchID_Anzahl, m_batchAnzahl;
    uint32_t len=64;
    unsigned char buf_r[64], buf_s[64], buf_livebit[64];
    bool read_info=false;
//*****************Device Parameter*****************//
    hid_device *handle;
    QString manufact_Name, product_String[5], m_deviceinfo[5];
    struct hid_device_info *devs, *cur_dev, *dev_event;

    int c_tab=0;                // Zähler für die Tabelle Tablewidget 2(Read form Device)
    struct table{
     QTableWidget *virt_table;
    }tabelle[50];


    static const int m_row= 999;
    static const int m_column=999;
    double m_x[m_row], m_y[m_column];
};




#endif // MAINWINDOW_H
