#include "hid_read_cmd.h"
#include "mainwindow.h"
#include "ui_mainwindow.h"


const uint8_t max=2;
int VE_ID[max]={5824,6988};
int PR_ID[max]={1158,65280};
unsigned char buffer[64];
unsigned char buffer_receive[64];
unsigned char buf_cmd[3];



//****************************************************
//VENDOR ID, PRODUKT ID
//****************************************************
bool VendorProduct_ID(int ve_id, int pr_id)
{
    bool v=false, p=false;

    for(uint8_t i=0; i<max; i++){
        if(ve_id==VE_ID[i]){
            v=true;
        }
        if(pr_id==PR_ID[i]){
            p=true;
        }
    }
    if(v && p){
        return true;
    }
    else{
        return false;
    }
}


//****************************************************
//INTERPRET CMD
//****************************************************
void interpretCmd(unsigned char *buf_send,unsigned char *buf_receive)
{

    qDebug()<<"Command interpretieren...";
    for(uint32_t i=0; i<64; i++){buffer[i]= *buf_receive++;}
     qDebug()<<buffer[3];

    for(uint32_t j=0; j<2; j++){buf_cmd[j]= *buf_send++;}
     qDebug()<<"buf_cmd stelle 0:"<<buf_cmd[0];

}


//****************************************************
//CMD CHECKSYNC  0x53, 0x54
//****************************************************
bool checkSync(unsigned char *buffer){
    qDebug()<<"CheckSync überprüfen...";
    if((buffer[0] == SYNCBYTE1)  && (buffer[1]  == SYNCBYTE2)){
        qDebug()<<"CheckSync o.k";
        return true;
    }else{
        return false;
          qDebug()<<"CheckSync falsch";
    }
}

//****************************************************
//CMD CHECKSUMME DEVICE PRÜFEN
//****************************************************
bool checkCRC(unsigned char *buf_r,unsigned char payload, uint32_t buf_len){
    qDebug()<<"CheckSumme überprüfen...";
    MainWindow Mainwindow;
    uint32_t k=0;
    int r_id=321;                               //Checksumme key
    unsigned char msg[buf_len];
    unsigned char buf[buf_len];
    uint32_t  p_len= payload+5;                 //Payloadlänge
    for(uint32_t i=0; i<buf_len; i++){
        msg[i]=*buf_r;
        buf[i]=*buf_r;
        buf_r++;
    }

   uint32_t chsm=Mainwindow.checksumme(msg, p_len, r_id);
   k= p_len;                  // cheksumme werte in buffer laden buf[k]
   msg[k+1] = chsm & 0xff;
   msg[k+2] = ( chsm >> 8 ) & 0xff;
   msg[k+3] = ( chsm >> 16 ) & 0xff;
   msg[k+4] = ( chsm >> 24 ) & 0xff;

   if(chsm==800){
      qDebug()<<"Checksumme: ID:: if send ID=123 if receive ID=321 unbekannt";
      return false;
   }
   else if(msg[k+1]==buf[k] && msg[k+2]==buf[k+1] && msg[k+3]==buf[k+2] && msg[k+4]==buf[k+3]){
      qDebug()<<"checksumme o.k";
       return true;
   }
   else{
      qDebug()<<"ChekSumme nicht Identisch";
      return false;
   }
}



//****************************************************
//CMD ID:0x01 Buffer[4]=0x01
//****************************************************
unsigned char cmdID_01(int index, unsigned char buf_5, unsigned char buf_6 ){
    int len=8;
   unsigned char msg[len];
    msg[0]=0;                     //Repor ID
    msg[1]=SYNCBYTE1;             //
    msg[2]=SYNCBYTE2;             //
    msg[3]=COMPONENTID;           //
    msg[4]=0x01;                  //       //
    msg[5]=0x02;                  //
    msg[6]=buf_5;                 //
    msg[7]=buf_6;

 switch(index){
    case 0:  return msg[index];
             break;
    case 1:  return msg[index];
             break;
    case 2:  return msg[index];
             break;
    case 3:  return msg[index];
             break;
    case 4:  return msg[index];
          break;
    case 5:  return msg[index];
          break;
    case 6:  return msg[index];
          break;
    case 7:  return msg[index];
          break;
 default:    return msg[index]=0;
             break;
 }

}

//****************************************************
//CMD ID:0x02 Buffer[4]=0x02
//****************************************************
unsigned char cmdID_02(int index, unsigned char buf_5,unsigned char buf_6){
    int len=8;
   unsigned char msg[len];
    msg[0]=0;                     //Repor ID
    msg[1]=SYNCBYTE1;             //
    msg[2]=SYNCBYTE2;             //
    msg[3]=COMPONENTID;           //
    msg[4]=0x02;                  //       //
    msg[5]=0x02;                  //
    msg[6]=buf_5;                 //
    msg[7]=buf_6;

 switch(index){
    case 0:  return msg[index];
             break;
    case 1:  return msg[index];
             break;
    case 2:  return msg[index];
             break;
    case 3:  return msg[index];
             break;
    case 4:  return msg[index];
          break;
    case 5:  return msg[index];
          break;
    case 6:  return msg[index];
          break;
    case 7:  return msg[index];
          break;
 default:    return msg[index]=0;
             break;
 }

}

//****************************************************
//CMD ID:0x03 Buffer[4]=0x03
//****************************************************
unsigned char cmdID_03(int index,unsigned char buf_5,unsigned char buf_6,unsigned char buf_7,unsigned char buf_8){
    int len=8;
   unsigned char msg[len];
    msg[0]=0;                     //Repor ID
    msg[1]=SYNCBYTE1;             //
    msg[2]=SYNCBYTE2;             //
    msg[3]=COMPONENTID;           //
    msg[4]=0x03;                  //       //
    msg[5]=0x04;                  //
    msg[6]=buf_5;                 //
    msg[7]=buf_6;
    msg[8]=buf_7;
    msg[9]=buf_8;

 switch(index){
    case 0:  return msg[index];
             break;
    case 1:  return msg[index];
             break;
    case 2:  return msg[index];
             break;
    case 3:  return msg[index];
             break;
    case 4:  return msg[index];
             break;
    case 5:  return msg[index];
             break;
    case 6:  return msg[index];
             break;
    case 7:  return msg[index];
             break;
    case 8:  return msg[index];
             break;
    case 9:  return msg[index];
             break;
 default:    return msg[index]=0;
             break;
 }

}

//****************************************************
//CMD ID:0x04 Buffer[4]=0x04
//****************************************************
unsigned char cmdID_04(int index, unsigned char buf_5,unsigned char buf_6,unsigned char buf_7,unsigned char buf_8){
    int len=8;
   unsigned char msg[len];
    msg[0]=0;                     //Repor ID
    msg[1]=SYNCBYTE1;             //
    msg[2]=SYNCBYTE2;             //
    msg[3]=COMPONENTID;           //
    msg[4]=0x04;                  //       //
    msg[5]=0x04;                  //
    msg[6]=buf_5;                  //
    msg[7]=buf_6;
    msg[8]=buf_7;
    msg[9]=buf_8;

 switch(index){
    case 0:  return msg[index];
             break;
    case 1:  return msg[index];
             break;
    case 2:  return msg[index];
             break;
    case 3:  return msg[index];
             break;
    case 4:  return msg[index];
             break;
    case 5:  return msg[index];
             break;
    case 6:  return msg[index];
             break;
    case 7:  return msg[index];
             break;
    case 8:  return msg[index];
             break;
    case 9:  return msg[index];
             break;
 default:    return msg[index]=0;
             break;
 }

}


//****************************************************
//READ OFFLOAD DATA: Korr Wert lesen
//****************************************************
 float ReadOffloadData(int index){

    float Batch_Anzahl ;
 switch(index){
     case 0: return Batch_Anzahl= (buffer_receive[5] << 24) | (buffer_receive[6] << 16) | (buffer_receive[7] << 8) | buffer_receive[8];  //Zeit Enum 0
             break;
     case 1: return Batch_Anzahl= buffer_receive[9];                       //limit      Enum 1
             break;
     case 2: return Batch_Anzahl=(buffer_receive[10] << 8) | buffer_receive[11];   //Batch ID   Enum 2
             break;
     case 3: return Batch_Anzahl=(buffer_receive[12] << 8) | buffer_receive[13];   //Korr. Wert Enum 3
             break;
     case 4: return Batch_Anzahl=(buffer_receive[14] << 8) | buffer_receive[15];   //Raw Wert   Enum 4
             break;
     case 5: return Batch_Anzahl=(buffer_receive[16] << 24) | (buffer_receive[17] << 16) | (buffer_receive[18] << 8) | buffer_receive[19]; //Phase 1 Enum 5
             break;
     case 6: return Batch_Anzahl=(buffer_receive[20] << 24) | (buffer_receive[21] << 16) | (buffer_receive[22] << 8) | buffer_receive[23]; //Phase 2 Enum 6
             break;
 default:    return -1;
             break;
    }
}

 //****************************************************
 //RECEIVE BUFFER
 //****************************************************
  void ReceivedBuffer(unsigned char *batchnumb){

      for(uint32_t i=0; i<64; i++){buffer_receive[i]= *batchnumb++;}

 }
//****************************************************
//READ NUMBER OF SAMPLE IN BATCH
//****************************************************
 uint32_t ReadNumberOfSpamleInBatch(unsigned char *batchnumb){

     for(uint32_t i=0; i<64; i++){buffer[i]= *batchnumb++;}
     uint8_t length = buffer[4];	// 9 bytes für sync Bytes, ComponentID,CmdID, Länge und CRC

     uint32_t Batch_Anzahl = (buffer[length+4] << 24) | (buffer[length+3] << 16) | (buffer[length+2] << 8) | buffer[length+1];
     return Batch_Anzahl;
}








